/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Application;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;

/**
 * FXML Controller class
 *
 * @author manish
 */
public class CalculatorFXMLController implements Initializable {

    private static double num1;
    private static String btnText = "";
    private static String operator;
    private static double num2;
    private static double res;
    
    @FXML
    private Label lblDisplay;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }

    @FXML
    public void processNumbers(ActionEvent event){
            btnText = ((Button)event.getSource()).getText();
            lblDisplay.setText(lblDisplay.getText()+btnText);
      
       
    
}  

    @FXML
    public void processOperators(ActionEvent event){
        
        String op = ((Button)event.getSource()).getText();
        
        if("=".equals(op)){
            String n2 = lblDisplay.getText();
            num2 = Double.parseDouble(n2);
            //System.out.println("num2 = " + num2);
            
            if("+".equals(operator))
                res = num1+num2;
            if("-".equals(operator))
                res = num1-num2;
            if("*".equals(operator))
                res = num1*num2;
            if("/".equals(operator))
                res = num1/num2;
            
            lblDisplay.setText(""+res);
            
            
        }else{
            String dtext = lblDisplay.getText();
        num1 = Double.parseDouble(dtext);
        operator = op;
       // System.out.println("num1 = " + num1);
            if("Clear".equals(op)){
                lblDisplay.setText(lblDisplay.getText().substring(0,lblDisplay.getText().length()-1));
                return;
            }
                
            if("All Clear".equals(op)){
                lblDisplay.setText("");
                return;
            }
                
                
            lblDisplay.setText("");
            //System.out.println("Operator = " + operator);
        }
    
} 
    
}
